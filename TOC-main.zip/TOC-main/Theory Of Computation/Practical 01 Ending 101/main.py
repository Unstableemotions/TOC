# Create a program that implements a machine that accepts strings ending with '101'

states = {
    "A": {
        "0": "A",
        "1": "B"
    },
    "B": {
        "0": "C",
        "1": "B"
    },
    "C": {
        "0": "A",
        "1": "D"
    },
    "D": {
        "0": "C",
        "1": "B"
    }
}
initial_state = "A"
final_state = "D"
def check_string(string:str):
    current_state = initial_state # By defaul initial state
    for s in string:
        # Transition to next state
        current_state = states[current_state][s]

    if current_state == final_state:
        return True
    return False

if __name__ == "__main__":

    user_input = input("Enter the string : ")

    X = check_string(user_input)
    print("Accepted" if X else "Not accepted")
