# Practical 7 (Write a program for generating regular expressions for regular grammar)
def generate_regex(regular_grammar):
    regex = ""
    for non_terminal, productions in regular_grammar.items():
        regex += f"{non_terminal} -> "
        if len(productions) == 1:
            regex += productions[0]
        else:
            regex += "(" + "|".join(productions) + ")"
        regex += "\n"
    return regex

# Test the function
regular_grammar = {
    'S': ['aA', 'bB', ''],
    'A': ['aA', ''],
    'B': ['bB', '']
}
regex = generate_regex(regular_grammar)
print("Regular expressions:")
print(regex)
