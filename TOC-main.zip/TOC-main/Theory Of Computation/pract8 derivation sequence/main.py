# Practical 8 (Write a program for generating derivation sequence / language for the given sequence of production)
def generate_derivation(grammar, start_symbol, max_depth):
    def derive(sentence, depth):
        if depth >= max_depth:
            return [sentence]
        derivations = []
        for i, symbol in enumerate(sentence):
            if symbol in grammar:
                for production in grammar[symbol]:
                    new_sentence = sentence[:i] + production + sentence[i+1:]
                    derivations.extend(derive(new_sentence, depth + 1))
        return derivations

    return derive(start_symbol, 0)

# Test the function
grammar = {
    'S': ['AB', 'BC'],
    'A': ['a'],
    'B': ['b'],
    'C': ['c']
}
start_symbol = 'S'
max_depth = 3
derivation_sequence = generate_derivation(grammar, start_symbol, max_depth)
print("Derivation sequence / Language:")
for derivation in derivation_sequence:
    print(derivation)

