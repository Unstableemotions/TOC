<h1>Theory of Computation – Practical</h1>
<br>

## Practical 1

    Design a Program for creating machine that accepts the string always ending with 101.

## Practical 2

    Design a program for accepting decimal number divisible by 2.

## Practical 3

    Write a program for tokenization of given input.

## Practical 4

    Design a Program for creating machine that accepts three consecutive one.

## Practical 5

    Design a Turing machine that’s accepts the even number of 1's.

## Practical 6

    Design a program for creating a machine which accepts string having equal no. of 1’s and 0’s.

## Practical 7

    Design a program for creating a machine which count number of 1’s and 0’s in a given string.
