states = {
    "A": {
        "0": "A",
        "1": "B"
    },
    "B": {
        "0": "A",
        "1": "C"
    },
    "C": {
        "0": "A",
        "1": "D"
    },
    "D": {
        "0": "A",
        "1": "A"
    }
}
initial_state = "A"
final_state = "D"
def three_consecutive_one(string: str):
    current_state = initial_state 
    consecutive_ones = 0
    for s in string:
        current_state = states[current_state][s]
        if current_state == "B":
            consecutive_ones = 1
        elif current_state == "C":
            consecutive_ones = 2
        elif current_state == "D":
            consecutive_ones = 3
        if consecutive_ones == 3:
            return True
    return False
if __name__ == "__main__":
    user_input = input("Enter the string: ")

    result = three_consecutive_one(user_input)
    print("Accepted" if result else "Not accepted")
